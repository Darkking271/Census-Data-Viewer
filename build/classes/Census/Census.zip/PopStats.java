/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Census;

import HashTable.HashTable;
import java.util.Set;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

/**
 *
 * @author Alex
 */
public class PopStats 
{
    private String monthsURL;
    private String statesURL;
    private String popURL;
    private String months[];
    private String states[];
    private String pop[];
    private HashTable<String, Integer> statesMap;
    private HashTable<String, Integer> monthMap;
    private int totalPop;
    private String monthNames[] = {"January", "Febuary", "March", "April", 
                                   "May", "June", "July", "August",
                                   "September", "October", "November", "December"};
    
    private String stateNames[] = {"Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut",
                                     "Delaware", "District of Columbia", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana",
                                     "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", 
                                     "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico",
                                     "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Puerto Rico",
                                     "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", 
                                     "Washington", "West Virginia", "Wisconsin", "Wyoming"};
    
    public PopStats(String monthsURL, String statesURL, String popURL) throws Exception
    {
        this.monthsURL = monthsURL;
        this.statesURL = statesURL;
        this.popURL = popURL;
        createMonths();
        createStates();
        createPop();
        statesMap = new HashTable<>();
        monthMap = new HashTable<>();
        Populate();
    }
    
    public String[] month()
    {
        return months;
    }
    
    public String[] states()
    {
        return states;
    }
    
    public void Populate()
    {
        totalPopulation();
        populateMonths();
        populateStates();
    }
    
    private void totalPopulation()
    {
        String usPop[] = pop[0].split("\"");
        totalPop = Integer.parseInt(usPop[1]);
    }
    
    private void populateMonths()
    {
        for (int i = 0; i < months.length; i++)
        {
            String data[] = months[i].split("\"");
            monthMap.put(monthNames[i], Integer.parseInt(data[1]));
        }
    }
    
    private void populateStates()
    {
        for (int i = 0; i < states.length; i++)
        {
            String data[] = states[i].split("\"");
            statesMap.put(stateNames[i], Integer.parseInt(data[1]));
        }
    }
    
    public int getStatePop(String state)
    {
        int statePop = statesMap.get(state);
        return statePop;
    }
    
    public int getMonthPop(String month)
    {
        int monthPop = monthMap.get(month);
        return monthPop;
    }
    
    public int getPop()
    {
        return totalPop;
    }
    
    public Set<String> getMonthSet()
    {
        return monthMap.alphaSet();
    }
    
    public Set<String> getStateSet()
    {
        return statesMap.alphaSet();
    }
    
    public boolean containsMonth(String month)
    {
        return monthMap.contains(month);
    }
    
    public boolean containsState(String state)
    {
        return statesMap.contains(state);
    }

    private void createMonths() throws Exception
    {
        URL site = new URL(monthsURL);
        BufferedReader in = new BufferedReader(
        new InputStreamReader(site.openStream()));

        String inputLine = in.readLine();
        months = new String[12];
        int i = 0;
        while ((inputLine = in.readLine()) != null)
        {
            months[i] = inputLine;
            i++;
        }
        in.close();
    }

    private void createStates() throws Exception
    {
        URL site = new URL(statesURL);
        BufferedReader in = new BufferedReader(
        new InputStreamReader(site.openStream()));

        String inputLine = in.readLine();
        states = new String[52];
        int i = 0;
        while ((inputLine = in.readLine()) != null)
        {
            states[i] = inputLine;
            i++;
        }
        in.close();
    }

    private void createPop() throws Exception
    {
        URL site = new URL(popURL);
        BufferedReader in = new BufferedReader(
        new InputStreamReader(site.openStream()));

        String inputLine = in.readLine();
        pop = new String[1];
        int i = 0;
        while ((inputLine = in.readLine()) != null)
        {
            pop[0] = inputLine;
            i++;
        }
        in.close();
    }
}
